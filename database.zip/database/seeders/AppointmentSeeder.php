<?php

namespace Database\Seeders;

use App\Models\Appointment;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AppointmentSeeder extends Seeder
{
    public function run(): void
    {
        $doctorIds = User::where('role', 'doctor')
            ->pluck('id')
            ->values();

        if ($doctorIds->isEmpty()) {
            $this->command->warn(
                'No doctors found. Please create doctor users before seeding appointments.'
            );

            return;
        }

        $appointments = [
            [
                'name' => 'Rahim Uddin',
                'email' => 'rahim@example.com',
                'date' => now()->addDay()->toDateString(),
                'time' => '10:00',
                'status' => 'confirmed',
                'reason' => 'Chest pain consultation',
                'extra' => [
                    'department' => 'Cardiology',
                    'notes' => 'Bring previous ECG report.',
                ],
            ],
            [
                'name' => 'Ayesha Khan',
                'email' => 'ayesha@example.com',
                'date' => now()->addDays(2)->toDateString(),
                'time' => '11:30',
                'status' => 'pending',
                'reason' => 'Fever and weakness',
                'extra' => [
                    'department' => 'Medicine',
                    'notes' => null,
                ],
            ],
            [
                'name' => 'Karim Ahmed',
                'email' => 'karim@example.com',
                'date' => now()->addDays(3)->toDateString(),
                'time' => '15:00',
                'status' => 'confirmed',
                'reason' => 'Knee pain',
                'extra' => [
                    'department' => 'Orthopedics',
                    'notes' => 'Follow-up visit.',
                ],
            ],
            [
                'name' => 'Nusrat Jahan',
                'email' => 'nusrat@example.com',
                'date' => now()->addDays(4)->toDateString(),
                'time' => '12:15',
                'status' => 'completed',
                'reason' => 'Routine checkup',
                'extra' => [
                    'department' => 'Gynecology',
                    'notes' => 'Completed successfully.',
                ],
            ],
            [
                'name' => 'Hasan Mahmud',
                'email' => 'hasan@example.com',
                'date' => now()->addDays(5)->toDateString(),
                'time' => '16:30',
                'status' => 'cancelled',
                'reason' => 'Headache consultation',
                'extra' => [
                    'department' => 'Neurology',
                    'notes' => 'Patient cancelled appointment.',
                ],
            ],
        ];

        foreach ($appointments as $index => $data) {
            $patient = User::updateOrCreate(
                [
                    'email' => $data['email'],
                ],
                [
                    'name' => $data['name'],
                    'password' => Hash::make('password'),
                    'role' => 'patient',
                ]
            );

            Appointment::create([
                'patient_id' => $patient->id,
                'doctor_id' => $doctorIds[$index % $doctorIds->count()],
                'appointment_date' => $data['date'],
                'appointment_time' => $data['time'],
                'status' => $data['status'],
                'reason' => $data['reason'],
                'extra' => $data['extra'],
            ]);
        }

        $this->command->info(
            count($appointments) . ' appointments seeded successfully.'
        );
    }
} 